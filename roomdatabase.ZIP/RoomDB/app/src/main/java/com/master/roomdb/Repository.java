package com.master.roomdb;

import android.app.Application;
import android.os.Handler;
import android.os.Looper;

import androidx.lifecycle.LiveData;

import java.util.List;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;



public class Repository {
    public final  ContactsDAO contactsDAO;
    ExecutorService service;
    Handler handler;
    public Repository(Application application) {
        ContactDatabase database=ContactDatabase.getInstance(application);
        this.contactsDAO=database.getContactDAO();
         service= Executors.newSingleThreadExecutor();
        handler=new Handler(Looper.getMainLooper());
    }

    public void addContact(Contact contact){
        service.execute(new Runnable() {
            @Override
            public void run() {
                contactsDAO.insert(contact);
            }
        });

    }
    public void DeleteContact(Contact contact){
        service.execute(new Runnable() {
            @Override
            public void run() {
                contactsDAO.delete(contact);
            }
        });

    }
    public LiveData<List<Contact>> getAllContact(){
// LiveData is an observable data holder class that allows you to observe
// changes in the database and automatically update the UI when the data changes.
        return  contactsDAO.getAllContacts();
    }
}
