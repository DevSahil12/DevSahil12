package com.master.roomdb;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;


import com.master.roomdb.databinding.ContactListItemBinding;

import java.util.ArrayList;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.ContactViewHolder> {

    public void setArrayList(ArrayList<Contact> arrayList) {
        this.arrayList = arrayList;
        notifyDataSetChanged();
    }

    private ArrayList<Contact> arrayList;
    public MyAdapter(ArrayList<Contact> arrayList) {
        this.arrayList = arrayList;
    }

    @NonNull
    @Override
    public ContactViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ContactListItemBinding contactListItemBinding=
                DataBindingUtil.inflate(LayoutInflater.from(parent.getContext())
                ,R.layout.contact_list_item
        ,parent,false);
        return new ContactViewHolder(contactListItemBinding);
    }

    @Override
    public void onBindViewHolder(@NonNull ContactViewHolder holder, int position) {
  Contact contact=new Contact();
  holder.contactListItemBinding.setContact(contact);
    }

    @Override
    public int getItemCount() {
        if (arrayList != null) {
            return arrayList.size();

        } else {
            return 0;
        }
    }


    class ContactViewHolder extends RecyclerView.ViewHolder{

    private ContactListItemBinding contactListItemBinding;

    public ContactViewHolder( ContactListItemBinding contactListItemBinding) {
        super(contactListItemBinding.getRoot());
        this.contactListItemBinding = contactListItemBinding;
    }

}
}
