package com.master.roomdb;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;

import com.master.roomdb.databinding.ActivityMainBinding;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
private ContactDatabase contactDatabase;
private ArrayList<Contact> contactArrayList=new ArrayList<>();
private ActivityMainBinding mainBinding;
private MainActivityViewHandler handler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        handler=new MainActivityViewHandler(this);
        setContentView(R.layout.activity_main);
        mainBinding= DataBindingUtil.setContentView(this,R.layout.activity_main);
        mainBinding.setClickHandler(handler);
        RecyclerView recyclerView=mainBinding.recyclerView;
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setHasFixedSize(true);
//Adapter
        MyAdapter adapter=new MyAdapter(contactArrayList);


        //database
        contactDatabase=ContactDatabase.getInstance(this);

        //ViewModel
        MyViewModel viewModel=new ViewModelProvider(this).get(MyViewModel.class);




        //Inserting new contact just for testing
Contact c1=new Contact("Sahil","Sahil123@gmail.com");
viewModel.InsertContact(c1);

//Load Data from the Database
viewModel.getAllContact().observe(this, new Observer<List<Contact>>() {
    @Override
    public void onChanged(List<Contact> contacts) {
        for (Contact c:contactArrayList){
            Log.v("TAGY",c.getName());
        }
    }
});

//Linking recycle View with the adapter
recyclerView.setAdapter(adapter);

    }
}