package com.master.roomdb;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import java.util.List;

public class MyViewModel extends AndroidViewModel {
    private  Repository repository;
    private LiveData<List<Contact>> AllContact;

    public MyViewModel(@NonNull Application application, Repository repository) {
        super(application);
        this.repository = new Repository(application);
    }

    public LiveData<List<Contact>> getAllContact() {
AllContact=repository.getAllContact();
return AllContact;
    }


public void deleteContact(Contact contact){
       repository.DeleteContact(contact);
}
public void InsertContact(Contact contact){
        repository.addContact(contact);
}


}
